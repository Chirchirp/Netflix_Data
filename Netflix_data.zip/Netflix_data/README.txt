
---------------------------------------------------------------------------------------------------
		Instructions on how to run the codes:
---------------------------------------------------------------------------------------------------
1. Run python code with jupyter notebook or VS Code to view statistical analysis of Netflix Data 
and different visualizations in python
	 
	The file is saved as "Module 4. Netflix Data"

2. To view Visualization in R, Run the Code using R studio
	
	The file is saved as "R Code to visualize Distrubution of Ratings"

			Thank you!